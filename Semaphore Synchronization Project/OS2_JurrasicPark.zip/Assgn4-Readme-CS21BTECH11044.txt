In the zip,
Assgn4-Src-CS21BTECH11044.cpp, to implement of follow below instructions.
File inp-params.txt is read by above cpp files to produce Output File. output.txt.

i)the file inp-params.txt contain:
	a)5 integers in 1st line (Num of passenger threasd, Num of car threads, lambda_p, lambda_c, K).

 Always, give input according to the above order.

ii)in Terminal, for compiling Cpp code Assgn4-Src-CS21BTECH11044.cpp:
	
	line 1:g++ Assgn4-Src-CS21BTECH11044.cpp -lpthread
	line 2:./a.out.

			

This takes input from "inp-params.txt" and generates "output.txt" which would contain LOG shown in Assgn Quen.


(imp)NOTE:
	Output File contains System time in format <Minutes> : <Seconds>. 
