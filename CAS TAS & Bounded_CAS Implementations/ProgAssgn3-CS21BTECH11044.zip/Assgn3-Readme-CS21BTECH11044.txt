In the zip,
Assgn3-Src-TAS-CS21BTECH11044.cpp, Assgn3-Src-CAS-CS21BTECH11044.cpp, Assgn3-Src-Bounded_CAS-CS21BTECH11044.cpp are 3 CPP Files 
to implentations of respective Methods.
File inp.txt is read by above cpp files to produce 3 Output Files. output_tas, output_cas, output_bounded_cas.

i)the file input.txt contain:
	a)4 integers in 1st line (Num of Threads, k, lambda_1, lambda_2).

 Always, give input according to the above order.

ii)in Terminal, for compiling Cpp code Assgn2Srcpthread_CS21BTECH11044.cpp:
	I)
	line 1:g++ Assgn3-Src-TAS-CS21BTECH11044.cpp -lpthread
	line 2:./a.out.
	II)
	line 1:g++ Assgn3-Src-CAS-CS21BTECH11044.cpp -lpthread
	line 2:./a.out.
	III)
	line 1:g++ Assgn3-Src-Bounded_CAS-CS21BTECH11044.cpp -lpthread
	line 2:./a.out.
			

This takes input from "inp.txt" and generates "output_tas.txt", "output_cas.txt", "output_bounded_cas.txt".


(imp)NOTE:
	Output File contains System time in format <Minutes> : <Seconds>. 
